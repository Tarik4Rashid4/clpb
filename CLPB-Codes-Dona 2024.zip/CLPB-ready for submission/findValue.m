% Disclaimer 

% The codes for this function have been taken from: 
%DOI: https://doi.org/10.1016/j.eij.2020.08.003

% Cite as:
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003


% This function always returns an even number of individuals.
function result = findValue(val)
x = mod(val, 4);
if x==0
    result = val;
end

if x~=0
    val = val+2;   
    result = val;
end
end