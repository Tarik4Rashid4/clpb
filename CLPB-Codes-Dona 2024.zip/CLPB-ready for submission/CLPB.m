%  Author and programmer: Dona A. Francis                      %
%                                                                   %
%         e-Mail: donnaalibak@gmail.com                             %
%                 dona.franci@cue.edu.krd                     %
%                 dona.amange@ukh.edu.krd                     %
%                                                                   %                                                                
%CLPB  is an improvement in LPB
%which includes different chaotic maps  to improve the performance of LPB , 
%the results shows that CLPB is better than LPB and other popular algorithms in 10  benchmark functions& 10 CEC-06-2019 functions.

%% % CLPB modification source codes by % % Dona A. Francis  % % % %
% % we improved the code of LPB which have been written by Chnoor M. Rahman % % then we embeded chaotic maps. % %%
% *** Cite our work as : Franci, D.A., Rashid, T.A. CLPB: chaotic learner performance based behaviour.
%  Int. j. inf. tecnol. (2024). https://doi.org/10.1007/s41870-024-01875-1 
%***

% disclaimer CODE of  LPB are taken from: 
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003
%_________________________________________________________________________%

clc;
clear;
close all;
tic;
%% Problem Definition

%CostFunction=@(x) CEC(x);     % Cost Function
%function_name='cec10';
%[fitness,lower_bound,upper_bound,dimensions ]=Select_Functions(function_name);
%
%[bestfit,BestPositions,fmax,BAT_Cg_curve]=REST1(N,Max_iter,lb,ub,dim,fobj);%
%display( num2str(bestfit));%
%summ=summ+bestfit;%
%A(i,:)=bestfit;%
%avg=summ/30;%
%[avg];%
%S_D=std(A);%
%if strcmp(Function_name,'Rest')%
%disp(['minimum Service time for workers in minutes
%is(fmin)',num2str(avg/60)]);%
%end%


nVar=10;                            % Number of Decision Variables ( Number of genes)  
 VarSize=[1 nVar];                   % Decision Variables Matrix Size                 
VarMin= -50;                        % Lower Bound of Variables                         
VarMax= 50;                         % Upper Bound of Variables                         

%% LPB Parameters

MaxIt=500;                   % Maximum Number of Iterations= 500 
nPop=80;                      % Population Size        
pc=0.6;                       % Crossover Percentage
nc=2*round(pc*nPop/2);        % Number of Offsprings (Parnets)    
pm=0.3;                       % Mutation Percentage
nm=round(pm*nPop);            % Number of Mutants               
gamma=0.05;
mu=0.03;                  % Mutation Rate
dp = 0.5;                 % didvide probability
beta = 8;
function_name='F14';
Chaotic_Map_Name='map9';

%% Initialization


empty_individual.Position=[];             
empty_individual.Cost=[];
pop=repmat(empty_individual,nPop,1);              
[fitness,lower_bound,upper_bound,dimensions]  = Select_Functions(function_name);
for i=1:nPop
    % Initialize Position
    
   xy=chaos(9,rand,1);                          % Modification1: chaos(ChaoticMap,rand,Dimention-1);for all TF use 9 just for TF14 USE 1 & TF19 USE 2 ....CEC01 use 8,CEC02 use 15, CEC03 use 17                                                         
                     
   pop(i).Position = lower_bound+xy*(upper_bound-lower_bound);  % Modification2
  

  %pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    %func=pop(i).Position;
    % Evaluation
    pop(i).Cost=fitness(pop(i).Position);
end
disp(function_name);
% Sort Population
Costs=[pop.Cost]; 
[Costs, SortOrder]=sort(Costs); 
pop=pop(SortOrder);
BestSol=pop(1);           
BestCost=zeros(MaxIt,1);  
WorstCost=pop(end).Cost;  
nfe=zeros(MaxIt,1);       

%% Main Loop
for it=1:MaxIt
    ncCheck = 1;
    % Calculate Selection Probabilities
    P=exp(-beta*Costs/WorstCost);
    P=P/sum(P);
    [fPop, wPop, gPop, pPop] = dividePopulation(pop, dp);
    val = findValue(numel(fPop(:,1)));
    val = floor(val/2);
    % first Population
    fPopindex = zeros(1, val);
    % counter for counting the first population index
    finCount = 1;
    nPopc2 = ceil(((0.25)*nPop)/2); 
    popc2=repmat(empty_individual,nPopc2,1);
    popc2Index = 1;
    for c=1:ceil(val/2)
        % Selecting parents from fPop
        i1 = parentSelection(fPop, fPopindex);
        i2 = parentSelection(fPop, fPopindex);
        fPopindex(finCount) = i1;      
        fPopindex(finCount+1) = i2;    
        
        parent1(finCount) = fPop(i1);
        parent2(finCount) = fPop(i2);
        
        parent1T = parent1(finCount).Position;    
        parent2T = parent2(finCount).Position;
        if ncCheck < nc                                                   
            popc2(popc2Index,1).Position = parent1T;             %selection operator
            popc2(popc2Index,2).Position = parent2T;             %selection operator
            popc2(popc2Index,1).Cost = parent1(finCount).Cost;
            popc2(popc2Index,2).Cost = parent2(finCount).Cost;
            % Apply Crossover to the chosen parents
            [child1, child2] =  Crossover(parent1T,parent2T,gamma,VarMin,VarMax);      %onePointCrossover(parent1T,parent2T);
            popc2(popc2Index+1,1).Position = child1;
            popc2(popc2Index+1,2).Position = child2;
            % Evaluate Offsprings
            popc2(popc2Index+1,1).Cost = fitness(popc2(popc2Index+1,1).Position);
            popc2(popc2Index+1,2).Cost = fitness(popc2(popc2Index+1,2).Position);
            ncCheck = ncCheck+1;
            popc2Index = popc2Index+2;
        else
            % Add parents to the new Population (popc2)
            popc2(popc2Index,1).Position = parent1T;
            popc2(popc2Index,2).Position = parent2T;
            popc2(popc2Index,1).Cost = parent1(finCount).Cost;
            popc2(popc2Index,2).Cost = parent2(finCount).Cost;
            popc2Index = popc2Index+1;
        end
        finCount = finCount+1;
        
    end
    pPopIndex = zeros(1, length(pPop));
    pPopCount = 1;
    numberOfpPopIndivs = size(pPopIndex);
    numberOfpPopIndivs = numberOfpPopIndivs(:,2);
    gPopIndex = zeros(1, length(gPop));
    gPopCount = 1;
    numberOfgPopIndivs = length(gPop);
    wPopIndex = zeros(1, length(wPop));
    wPopCount = 1;
    for c2=1:val
        % Selecting 1st parent from better population (fPop)
        i1 = parentSelection(fPop, fPopindex);
        fPopindex(finCount) = i1;
        parent1(finCount) = fPop(i1);
        if(numberOfpPopIndivs~=1)
            % Selecting 2nd parent from perfect population (pPop)
            i2 = parentSelection(pPop, pPopIndex);
            pPopindex(pPopCount) = i2;
            parent2(finCount) = pPop(i2);
            numberOfpPopIndivs = numberOfpPopIndivs-1;
        else
            if(numberOfgPopIndivs~=1)
                % Selecting 2nd parent from good population (gPop)
                i2 = parentSelection(gPop, gPopIndex);
                gPopindex(gPopCount) = i2;
                parent2(finCount) = gPop(i2);
                numberOfgPopIndivs = numberOfgPopIndivs-1;
            else
                % Selecting 2nd parent from worst population (wPop)
                i2 = parentSelection(wPop, wPopIndex);
                wPopindex(wPopCount) = i2;
                parent2(finCount) = wPop(i2);
            end
        end
        parent1T = parent1(finCount).Position;
        parent2T = parent2(finCount).Position;
        if ncCheck < nc
            popc2(popc2Index,1).Position = parent1T;
            popc2(popc2Index,2).Position = parent2T;
            popc2(popc2Index,1).Cost = parent1(finCount).Cost;
            popc2(popc2Index,2).Cost = parent2(finCount).Cost;
            [child1P, child2P] =  Crossover(parent1T,parent2T,gamma,VarMin,VarMax);
            popc2(popc2Index+1,1).Position = child1P;
            popc2(popc2Index+1,2).Position = child2P;
            
            %Evaluate Offsprings
            popc2(popc2Index+1,1).Cost = fitness(popc2(popc2Index+1,1).Position);
            popc2(popc2Index+1,2).Cost = fitness(popc2(popc2Index+1,2).Position);
            ncCheck = ncCheck+1;
            popc2Index = popc2Index+2;
        else
            popc2(popc2Index,1).Position = parent1T;
            popc2(popc2Index,2).Position = parent2T;
            popc2(popc2Index,1).Cost = parent1(finCount).Cost;
            popc2(popc2Index,2).Cost = parent2(finCount).Cost;
            popc2Index = popc2Index+1;
            
        end
        finCount = finCount+1;
        
    end
    popc2=popc2(:);
    
    % Mutation
    for k=1:nm
        % Select Parent
        i=randi([1 numel(popc2)]);
        p=popc2(i);
        % Apply Mutation
        popc2(i).Position=Mutate(p.Position,mu,VarMin,VarMax);
        
        % Evaluate Mutant
        popc2(i).Cost=fitness(popc2(i).Position);
    end
    popc2Size = numel(popc2);
    size_ = nPop-popc2Size;
    
    for i=1:(size_+1)
        popc2(popc2Size) = pop(i);
        popc2Size = popc2Size + 1;
    end
    %pop=popc2;
    % Create Merged Population
    pop=[popc2
        pop];
    % Sort Population
    Positions=[pop.Position];
    Costs=[pop.Cost];
    
    [Costs, SortOrder]=sort(Costs);
    pop=pop(SortOrder);
    
    % Update Worst Cost
    WorstCost=max(WorstCost,pop(end).Cost);
    
    % Truncation
    pop=pop(1:nPop);
    Costs=Costs(1:nPop);
    
    % Store Best Solution Ever Found
    BestSol=pop(1);
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol.Cost;
    
    % Show Iteration Information
    disp(['Iteration ' num2str(it)  ', Best Cost = ' num2str(BestCost(it))]);
end
toc;

%% Results

figure(1)
semilogy(nfe,BestCost,'LineWidth',2);
plot(BestCost,'LineWidth',2);
xlabel('Iteration');
ylabel('Cost');