% Disclaimer 

% The codes for this function have been taken from: 
%DOI: https://doi.org/10.1016/j.eij.2020.08.003

% Cite as:
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003

function y=Mutate(x,mu,VarMin,VarMax)
    nVar=numel(x);
    
    nmu=ceil(mu*nVar);
    
    j=randsample(nVar,nmu);
    
    sigma=0.1*(VarMax-VarMin);
    
    y=x;
    y(j)=x(j)+sigma*randn(size(j));
    
    y=max(y,VarMin);
    y=min(y,VarMax);
end