
% these are IEEE CEC-C06 benchmarks test function for single optimizations problems
% known as "The 100-Digit Challenge", for more info: http://web.mysites.ntu.edu.sg/epnsugan/PublicSite/Shared%20Documents/CEC-2019/Definitions%20of%20%20CEC2019%20Benchmark%20Sute.pdf

%                                                                   %
%  Author and programmer: Dona A. Francis                      %
%                                                                   %
%         e-Mail: donnaalibak@gmail.com                             %
%                 dona.franci@cue.edu.krd                     %
%                 dona.amange@ukh.edu.krd                     %
%                                                                   %
%*** Cite our work as : Franci, D.A., Rashid, T.A. CLPB: chaotic learner performance based behaviour.
%  Int. j. inf. tecnol. (2024). https://doi.org/10.1007/s41870-024-01875-1 
%***
%
%                                                                   %
% This code is an implementation of CEC-06 2019  single objective   %
% benchmark functions from CEC01 to CEC10	
				        %
%    this is taken from the work that is cited as:                                                               %
% J. M. Abdullah and T. A. Rashid, "Fitness Dependent Optimizer: 
% Inspired by the Bee Swarming Reproductive Process," in IEEE Access.
% doi: 10.1109/ACCESS.2019.2907012
% keywords: {Optimization;Swarm Intelligence;Evolutionary Computation;Metaheuristic Algorithms;Fitness Dependent Optimizer;FDO},
% URL: http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=8672851&isnumber=6514899               %
%  

%% ************ cec01 Dim = 9******************************** [-8192, 8192]
function cost = CEC(x)
dimension =9;
a = 0.0;
b = 0.0;
c = 0.0; 
d = 72.661;
u = 0.0;
v = 0.0;
wk = 0.0;
pk= 0.0;
m = 32*dimension;

for i=1 : dimension
    u = u+ x(1,i) * (1.2)^(dimension-i);
end
if u < d
    a = (u-d)^2;
end

for i=1 : dimension
    v = v+ x(1,i) * (-1.2)^(dimension-i);
end
if v < d
    b = (v-d)^2;
end

for k=0 :m
    for i=1 : dimension
        wk = wk+ x(1,i) * ((2*k/m)-1)^(dimension-i);
    end
    if wk > d
        pk = pk+ (wk-d)^2;
    elseif wk < d
        pk = pk +(wk+d)^2;
    else
        pk = pk +0.0;
    end
end
c =  pk;
cost =  a + b + c;


end
