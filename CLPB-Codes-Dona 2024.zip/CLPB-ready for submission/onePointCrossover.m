% Disclaimer 

% The codes for this function have been taken from: 
%DOI: https://doi.org/10.1016/j.eij.2020.08.003

% Cite as:
% Rahman, C. and Rashid, T., 2020. A new evolutionary algorithm: Learner performance based behavior algorithm. 
% Egyptian Informatics Journal. DOI: https://doi.org/10.1016/j.eij.2020.08.003

function [child1, child2] = onePointCrossover(parent1, parent2)

child1 = parent1;
child2 = parent2;

% define the crossover point randomly
[r c] = size(parent1);    
CrossoverIndex = randi(c);

% parent
child1 = [parent1(1:CrossoverIndex) parent2(CrossoverIndex+1:end)];
child2 = [parent2(1:CrossoverIndex) parent1(CrossoverIndex+1:end)];

end